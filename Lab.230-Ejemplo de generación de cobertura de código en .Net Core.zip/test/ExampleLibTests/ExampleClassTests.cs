using System;
using Xunit;
using ExampleLib;
using FluentAssertions;

namespace ExampleLibTests
{
    public class ExampleClassTests
    {
        [Fact]
        public void Add_ShouldBe5_IfA3AndB2()
        {
            //Arrange
            var a = 3;
            var b = 2;

            //Act
            var result = ExampleClass.Add(a,b);

            //Assert
            result.Should().Be(5);
        }
    }
}
