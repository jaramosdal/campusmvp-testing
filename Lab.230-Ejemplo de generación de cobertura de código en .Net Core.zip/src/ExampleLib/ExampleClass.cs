﻿using System;

namespace ExampleLib
{
    public static class ExampleClass
    {
        public static int Add(int a, int b) => a + b;
    }
}
