using EntityFramework6;
using Moq;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using FluentAssertions;
using Xunit;

namespace EntityFramework6Tests
{
    public class SyncTests
    {
        private readonly AcademyDbContext _dbContext;

        public SyncTests()
        {
            //Creamos los objetos en memoria
            var course = new Course { City = "Madrid", Name = "Mocking" };
            var student = new Student { IdCourse = course.IdCourse, Course = course, Name = "Alumno1 Garcia" };
            course.Students.Add(student);

            //Creamos las colecciones IQueryable en memoria
            var mockCourses = new List<Course>()
            {
                course
            }.AsQueryable();
            var mockStudents = new List<Student>()
            {
                student
            }.AsQueryable();

            //Creamos los DbSet
            var coursesDbSetMock = new Mock<DbSet<Course>>();
            coursesDbSetMock.As<IQueryable<Course>>().Setup(m => m.Provider).Returns(mockCourses.Provider);
            coursesDbSetMock.As<IQueryable<Course>>().Setup(m => m.Expression).Returns(mockCourses.Expression);
            coursesDbSetMock.As<IQueryable<Course>>().Setup(m => m.ElementType).Returns(mockCourses.ElementType);
            coursesDbSetMock.As<IQueryable<Course>>().Setup(m => m.GetEnumerator()).Returns(mockCourses.GetEnumerator());

            var studentsDbSetMock = new Mock<DbSet<Student>>();
            studentsDbSetMock.As<IQueryable<Student>>().Setup(m => m.Provider).Returns(mockStudents.Provider);
            studentsDbSetMock.As<IQueryable<Student>>().Setup(m => m.Expression).Returns(mockStudents.Expression);
            studentsDbSetMock.As<IQueryable<Student>>().Setup(m => m.ElementType).Returns(mockStudents.ElementType);
            studentsDbSetMock.As<IQueryable<Student>>().Setup(m => m.GetEnumerator()).Returns(mockStudents.GetEnumerator());

            //Creamos el mock del DbContext
            var dbContextMock = new Mock<AcademyDbContext>();
            dbContextMock.Setup(c => c.Courses).Returns(coursesDbSetMock.Object);
            dbContextMock.Setup(c => c.Students).Returns(studentsDbSetMock.Object);

            _dbContext = dbContextMock.Object;
        }

        [Fact]
        public void Coruse_ShouldBe1With1Student()
        {
            //Arrange

            //Act
            var result = _dbContext.Courses.ToList();

            //Assert
            result.Should().HaveCount(1);
            result[0].Students.Should().HaveCount(1);
        }
    }
}
