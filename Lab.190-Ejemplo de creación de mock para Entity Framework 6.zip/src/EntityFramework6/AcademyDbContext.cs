﻿using System.Data.Entity;

namespace EntityFramework6
{
    public partial class AcademyDbContext : DbContext
    {
        public AcademyDbContext()
        {
        }

        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<Course> Courses { get; set; }
    }
}
