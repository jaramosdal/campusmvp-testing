﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EntityFramework6
{
    public class Student
    {
        [Key]
        public int IdStudent { get; set; }
        public string Name { get; set; }
        public DateTime Birthdate { get; set; }
        public int IdCourse { get; set; }

        public Course Course { get; set; }
    }
}
