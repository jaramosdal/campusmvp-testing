﻿using System;

namespace EjercicioRefactorNetFramework.Services.Centralita
{
    public class ServicioTelefonia
    {
        public void LlamarPorTelefono(string nombreUsuario)
        {
            Console.WriteLine($"Llamando por telefono a {nombreUsuario}");
        }
    }
}
