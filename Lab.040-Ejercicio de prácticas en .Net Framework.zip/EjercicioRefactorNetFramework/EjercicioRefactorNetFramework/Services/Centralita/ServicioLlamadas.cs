﻿namespace EjercicioRefactorNetFramework.Services.Centralita
{
    public class ServicioLlamadas
    {
        public void Llamar(string nombreUsuario)
        {
            var telefono = new ServicioTelefonia();
            telefono.LlamarPorTelefono(nombreUsuario);
        }
    }
}
