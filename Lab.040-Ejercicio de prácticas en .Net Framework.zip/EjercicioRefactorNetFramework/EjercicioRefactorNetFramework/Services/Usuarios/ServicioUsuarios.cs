﻿using EjercicioRefactorNetFramework.Services.Centralita;

namespace EjercicioRefactorNetFramework.Services.Usuarios
{
    public class ServicioUsuarios
    {

        public bool ExisteUsuario(string nombreUsuario)
        {
            //...
            return true;
        }

        public void LlamarAlUsuario(string nombreUsuario)
        {
            var centralita = new ServicioLlamadas();
            centralita.Llamar(nombreUsuario);
        }
    }
}
