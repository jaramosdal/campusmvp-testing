﻿using EjercicioRefactorNetFramework.Services.Usuarios;
using System;

namespace EjercicioRefactorNetFramework
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var nombreUsuario = "Jorge Turrado";
            var servicioUsuarios = new ServicioUsuarios();

            if (servicioUsuarios.ExisteUsuario(nombreUsuario))
            {
                servicioUsuarios.LlamarAlUsuario(nombreUsuario);
            }
            Console.Read();
        }
    }
}
