﻿namespace Design.Tests.ExampleAssets
{
    public class AlarmMonitorAttribute : MonitorAttribute
    {
        public AlarmMonitorAttribute() : base(3)
        {

        }
    }
}
