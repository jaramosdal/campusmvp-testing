﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EntityFrameworkCore
{
    public class Course
    {
        public Course()
        {
            Students = new HashSet<Student>();
        }
        [Key]
        public int IdCourse { get; set; }
        public string Name { get; set; }
        public string City { get; set; }

        public ICollection<Student> Students { get; set; }
    }
}
