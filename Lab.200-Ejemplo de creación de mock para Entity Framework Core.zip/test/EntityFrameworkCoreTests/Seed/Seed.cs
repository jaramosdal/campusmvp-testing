﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using EntityFrameworkCore;

namespace EntityFrameworkCoreTests.Seed
{
    public static class Seed
    {
        public static void InitializeDatabase(AcademyDbContext context)
        {
            var course = new Course { City = "Madrid", Name = "Mocking" };
            var student = new Student { IdCourse = course.IdCourse, Course = course, Name = "Alumno1 Garcia" };
            course.Students.Add(student);

            context.Courses.Add(course);
            context.Students.Add(student);
            context.SaveChanges();
        }
    }
}

