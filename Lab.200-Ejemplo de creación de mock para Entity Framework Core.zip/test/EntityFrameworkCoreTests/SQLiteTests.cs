using EntityFrameworkCore;
using FluentAssertions;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using Xunit;

namespace EntityFrameworkCoreTests
{
    public class SQLiteTests : IDisposable
    {
        private readonly AcademyDbContext _dbContext;
        private readonly SqliteConnection _connection;

        public SQLiteTests()
        {
            _connection = new SqliteConnection("DataSource=:memory:");
            _connection.Open();


            var options = new DbContextOptionsBuilder<AcademyDbContext>()
                .UseSqlite(_connection)
                .Options;

            _dbContext = new AcademyDbContext(options);
            _dbContext.Database.EnsureCreated();
            Seed.Seed.InitializeDatabase(_dbContext);
        }

        [Fact]
        public async Task Coruse_ShouldBe1With1Student()
        {
            //Arrange

            //Act
            var result = await _dbContext.Courses.ToListAsync();

            //Assert
            result.Should().HaveCount(1);
            result[0].Students.Should().HaveCount(1);
        }

        public void Dispose()
        {
            _dbContext?.Dispose();
            _connection.Dispose();
        }
    }
}
