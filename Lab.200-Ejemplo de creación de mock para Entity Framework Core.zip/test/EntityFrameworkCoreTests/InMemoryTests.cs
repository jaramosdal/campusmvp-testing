using System;
using EntityFrameworkCore;
using FluentAssertions;
using Moq;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace EntityFrameworkCoreTests
{
    public class InMemoryTests: IDisposable
    {
        private readonly AcademyDbContext _dbContext;

        public InMemoryTests()
        {
            var options = new DbContextOptionsBuilder<AcademyDbContext>()
                .UseInMemoryDatabase(databaseName: "Add_writes_to_database")
                .Options;

            _dbContext = new AcademyDbContext(options);
            Seed.Seed.InitializeDatabase(_dbContext);
        }

        [Fact]
        public void Coruse_ShouldBe1With1Student()
        {
            //Arrange

            //Act
            var result = _dbContext.Courses.ToList();

            //Assert
            result.Should().HaveCount(1);
            result[0].Students.Should().HaveCount(1);
        }

        public void Dispose()
        {
            _dbContext?.Dispose();
        }
    }
}
