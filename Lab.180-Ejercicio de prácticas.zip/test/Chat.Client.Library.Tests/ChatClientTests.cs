﻿using Chat.Client.Library.Services;
using Chat.Common.Entities;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace Chat.Client.Library.Tests
{
    public class ChatClientTests : IDisposable
    {
        private readonly IChatClient _chatClient;
        private readonly MockRepository _repository;
        private readonly Mock<IUserApiClient> _userApi;
        private readonly Mock<IChatApiClient> _chatApi;

        public ChatClientTests()
        {
            _repository = new MockRepository(MockBehavior.Strict);
            _chatApi = _repository.Create<IChatApiClient>();
            _userApi = _repository.Create<IUserApiClient>();

            _userApi.Setup(user => user.LoginAsync("Usuario1", "P2ssw0rd!")).Returns(Task.FromResult(new ChatUser { Name = "Usuario1" }));
            _userApi.Setup(user => user.LoginAsync("Usuario2", "")).Returns(Task.FromResult<ChatUser>(null));
            _userApi.Setup(user => user.LoginAsync("Usuario3", "P2ssw0rd!")).Returns(Task.FromResult(new ChatUser { Name = "Usuario3" }));
            _userApi.Setup(user => user.CreateUserAsync("Usuario1", "P2ssw0rd!")).Returns(Task.FromResult(new ChatUser()));
            _userApi.Setup(user => user.CreateUserAsync("Usuario2", "")).Returns(Task.FromResult<ChatUser>(null));

            _chatApi.Setup(chat => chat.SendMessageAsync(It.IsAny<ChatMessage>())).Returns(Task.FromResult(true));

            var messages = new List<ChatMessage>
            {
                new ChatMessage
                {
                    Author = "Usuario3",
                    Message = "Test",
                    Date = DateTime.Now
                }
            };
            _chatApi.Setup(chat => chat.GetChatMessagesAsync()).Returns(Task.FromResult((IEnumerable<ChatMessage>)messages));

            _chatClient = new ChatClient(_chatApi.Object, _userApi.Object);
        }

        [Theory]
        [InlineData(true, "Usuario1", "P2ssw0rd!")]
        [InlineData(false, "Usuario2", "")]
        public async Task LoginAsync_ShouldBeExpectedResult(bool expected, string username, string password)
        {
            //Arrange

            //Act
            var result = await _chatClient.LoginAsync(username, password);

            //Assert
            Assert.Equal(expected, result);
        }

        [Fact]
        public void LoginAsync_ShouldBeArgumentNullException_IfArgumentNull()
        {
            //Arrange

            //Act
            Func<Task> act = async () => { _ = await _chatClient.LoginAsync(null, null); };

            //Assert
            Assert.ThrowsAsync<ArgumentNullException>(act);

        }

        [Theory]
        [InlineData(true, "Usuario1", "P2ssw0rd!")]
        [InlineData(false, "Usuario2", "")]
        public async Task CreateUserAsync_ShouldBeExpectedResult(bool expected, string username, string password)
        {
            //Arrange

            //Act
            var result = await _chatClient.CreateUserAsync(username, password);

            //Assert
            Assert.Equal(expected, result);
        }

        [Fact]
        public void CreateUserAsync_ShouldBeArgumentNullException_IfArgumentNull()
        {
            //Arrange

            //Act
            Func<Task> act = async () => { _ = await _chatClient.CreateUserAsync(null, null); };

            //Assert
            Assert.ThrowsAsync<ArgumentNullException>(act);

        }

        [Fact]
        public async Task SendMessageAsync_ShouldBeTrue_IfLoggedAndConnected()
        {
            //Arrange
            var message = "Message1";
            await _chatClient.LoginAsync("Usuario1", "P2ssw0rd!");
            _chatClient.Connect();

            //Act
            var result = await _chatClient.SendMessageAsync(message);

            //Assert
            Assert.True(result);
        }

        [Fact]
        public async Task SendMessageAsync_ShouldBeFalse_IfNotLogged()
        {
            //Arrange
            var message = "Message1";

            //Act
            var result = await _chatClient.SendMessageAsync(message);

            //Assert
            Assert.False(result);
        }

        [Fact]
        public async Task NewMessageRecived_ShouldBeRaised_IfConnect()
        {
            //Arrange
            var eventRecived = false;
            await _chatClient.LoginAsync("Usuario1", "P2ssw0rd!");
            _chatClient.NewMessageRecived += (sender, _) => eventRecived = true;
            _chatClient.Connect();

            //Act
            await Task.Delay(100); //Le damos tiempo para que se ejecute el evento

            //Assert
            Assert.True(eventRecived);
        }

        [Fact]
        public async Task OverwriteLastLine_ShouldBeRaised_IfOneMessageAndAuthorIsWhoseIsLogged()
        {
            //Arrange
            var eventRecived = false;
            await _chatClient.LoginAsync("Usuario3", "P2ssw0rd!");
            _chatClient.OverwriteLastLine += (sender, _) => eventRecived = true;
            _chatClient.Connect();

            //Act
            await Task.Delay(100); //Le damos tiempo para que se ejecute el evento

            //Assert
            Assert.True(eventRecived);
        }

        [Fact]
        public async Task OverwriteLastLine_ShouldNotBeRaised_IfOneMessageAndAuthorIsOther()
        {
            //Arrange
            var eventRecived = false;
            await _chatClient.LoginAsync("Usuario1", "P2ssw0rd!");
            _chatClient.OverwriteLastLine += (sender, _) => eventRecived = true;
            _chatClient.Connect();

            //Act
            await Task.Delay(100); //Le damos tiempo para que se ejecute el evento

            //Assert
            Assert.False(eventRecived);
        }

        [Fact]
        public async Task OverwriteLastLine_ShouldNotBeRaised_IfMoreThanOneMessage()
        {
            //Arrange
            var eventRecived = false;
            var messages = new List<ChatMessage>
            {
                new ChatMessage
                {
                    Author = "Usuario3",
                    Message = "Test",
                    Date = DateTime.Now
                },
                new ChatMessage
                {
                    Author = "Usuario3",
                    Message = "Test",
                    Date = DateTime.Now
                }
            };
            _chatApi.Setup(chat => chat.GetChatMessagesAsync()).Returns(Task.FromResult((IEnumerable<ChatMessage>)messages));
            await _chatClient.LoginAsync("Usuario1", "P2ssw0rd!");
            _chatClient.OverwriteLastLine += (sender, _) => eventRecived = true;
            _chatClient.Connect();

            //Act
            await Task.Delay(100); //Le damos tiempo para que se ejecute el evento

            //Assert
            Assert.False(eventRecived);
        }

        public void Dispose()
        {
            _chatClient?.Dispose();
        }
    }
}
